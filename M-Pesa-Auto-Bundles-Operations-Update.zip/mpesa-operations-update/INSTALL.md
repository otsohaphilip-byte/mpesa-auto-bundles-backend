# M-Pesa Auto Bundles — operations feature module

This is a **feature module**, not a complete replacement backend. It adds database-backed global pause/resume, reseller notification history endpoints, offer daily start/end database columns, and Africa/Nairobi daily-window logic. It does NOT implement payment matching, bundle fulfilment, push notifications, or a reseller dashboard screen.

## Integration into the existing server.js
1. Beside the existing `require(...)` statements add:
   `const { installOperations } = require('./operations');`
2. In the startup block, change `initializeDatabase().then(() => {` to `initializeDatabase().then(async () => {` and add this line immediately inside the callback before `app.listen(...)`:
   `await installOperations(app, pool, authenticateToken, requireAdmin, requireReseller);`
3. Before the startup block add:
   `app.get('/admin-controls.js', (req, res) => res.sendFile(path.join(__dirname, 'admin-controls.js')));`
4. In `admin.html`, immediately before `</body>`, add:
   `<script src="/admin-controls.js"></script>`
5. Upload `operations.js`, `admin-controls.js`, and the two small integration edits to the `complete-app-development` branch. Keep the production Render deployment untouched until tests pass.

## Important: do not enable live sales yet
The current backend has no real order-creation/payment-matching pipeline. This module therefore does not claim that the pause flag already blocks purchases or that timed offers are enforced during payment matching. When implementing that pipeline, it MUST check `await getSalesPaused(pool)` before creating a new sale, while still accepting and recording Safaricom confirmation callbacks. It MUST check `isWithinDailyWindow(offer.daily_start_time, offer.daily_end_time, new Date())` immediately before matching an offer. Already-paid orders must be retained for manual review/refund handling if an offer expires. Never send a bundle based on an ambiguous payment match.

## Test
Run `node --test tests/operations.test.js`. Tests cover Nairobi timezone, same-day and overnight schedules, unscheduled offers, invalid times, and equal start/end times. PostgreSQL integration and full backend tests are still required before deployment.
