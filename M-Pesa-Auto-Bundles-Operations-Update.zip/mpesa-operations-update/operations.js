'use strict';
const NAIROBI_TZ = 'Africa/Nairobi';
function minutesInNairobi(date = new Date()) {
  const parts = new Intl.DateTimeFormat('en-GB', { timeZone: NAIROBI_TZ, hour: '2-digit', minute: '2-digit', hourCycle: 'h23' }).formatToParts(date);
  const hour = Number(parts.find(p => p.type === 'hour').value);
  const minute = Number(parts.find(p => p.type === 'minute').value);
  return hour * 60 + minute;
}
function validTime(value) { return typeof value === 'string' && /^([01]\d|2[0-3]):[0-5]\d$/.test(value); }
function isWithinDailyWindow(start, end, date = new Date()) {
  if (start == null && end == null) return true;
  if (!validTime(start) || !validTime(end) || start === end) return false;
  const now = minutesInNairobi(date);
  const toMinutes = value => Number(value.slice(0, 2)) * 60 + Number(value.slice(3));
  const from = toMinutes(start), until = toMinutes(end);
  return from < until ? now >= from && now < until : now >= from || now < until;
}
async function installOperations(app, pool, authenticateToken, requireAdmin, requireReseller) {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS platform_settings (setting_key VARCHAR(80) PRIMARY KEY, setting_value JSONB NOT NULL, updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW());
    INSERT INTO platform_settings (setting_key, setting_value) VALUES ('sales_paused', '{"paused":false,"reason":null}'::jsonb) ON CONFLICT (setting_key) DO NOTHING;
    CREATE TABLE IF NOT EXISTS reseller_notifications (id BIGSERIAL PRIMARY KEY, reseller_id BIGINT NOT NULL REFERENCES resellers(id) ON DELETE CASCADE, event_type VARCHAR(40) NOT NULL, title VARCHAR(160) NOT NULL, message TEXT NOT NULL, created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(), read_at TIMESTAMPTZ);
    ALTER TABLE offers ADD COLUMN IF NOT EXISTS daily_start_time TIME;
    ALTER TABLE offers ADD COLUMN IF NOT EXISTS daily_end_time TIME;
    CREATE INDEX IF NOT EXISTS idx_reseller_notifications_unread ON reseller_notifications(reseller_id, created_at DESC) WHERE read_at IS NULL;
  `);
  app.get('/api/system/sales-status', authenticateToken, async (req, res) => {
    try { const r = await pool.query("SELECT setting_value, updated_at FROM platform_settings WHERE setting_key='sales_paused'"); const s = r.rows[0]?.setting_value || { paused: false, reason: null }; res.json({ status: 'OK', paused: Boolean(s.paused), reason: s.reason || null, updated_at: r.rows[0]?.updated_at || null }); }
    catch (e) { console.error('Sales status error:', e); res.status(500).json({ status: 'ERROR', message: 'Could not load sales status.' }); }
  });
  app.patch('/api/admin/system/sales-status', authenticateToken, requireAdmin, async (req, res) => {
    const paused = req.body?.paused, reason = typeof req.body?.reason === 'string' ? req.body.reason.trim().slice(0, 250) : null;
    if (typeof paused !== 'boolean') return res.status(400).json({ status: 'ERROR', message: 'paused must be true or false.' });
    const c = await pool.connect();
    try {
      await c.query('BEGIN');
      const old = await c.query("SELECT setting_value FROM platform_settings WHERE setting_key='sales_paused' FOR UPDATE");
      const wasPaused = Boolean(old.rows[0]?.setting_value?.paused);
      await c.query("INSERT INTO platform_settings(setting_key,setting_value,updated_at) VALUES('sales_paused',$1::jsonb,NOW()) ON CONFLICT(setting_key) DO UPDATE SET setting_value=EXCLUDED.setting_value,updated_at=NOW()", [JSON.stringify({ paused, reason: paused ? (reason || 'Sales temporarily paused by administrator.') : null })]);
      if (wasPaused !== paused) {
        const title = paused ? 'Platform sales paused' : 'Platform sales resumed';
        const message = paused ? (reason || 'The administrator has temporarily paused new sales. Payments already made will still be recorded.') : 'The administrator has resumed platform sales. New sales may proceed subject to offer availability.';
        await c.query("INSERT INTO reseller_notifications(reseller_id,event_type,title,message) SELECT id,$1,$2,$3 FROM resellers WHERE status='active'", [paused ? 'sales_paused' : 'sales_resumed', title, message]);
      }
      await c.query('COMMIT');
      res.json({ status: 'OK', paused, changed: wasPaused !== paused, message: paused ? 'New sales are paused. Payment callbacks remain enabled.' : 'Sales have resumed.' });
    } catch (e) { await c.query('ROLLBACK'); console.error('Set sales status error:', e); res.status(500).json({ status: 'ERROR', message: 'Could not update sales status.' }); }
    finally { c.release(); }
  });
  app.get('/api/resellers/notifications', authenticateToken, requireReseller, async (req, res) => {
    try { const r = await pool.query('SELECT id,event_type,title,message,created_at,read_at FROM reseller_notifications WHERE reseller_id=$1 ORDER BY created_at DESC LIMIT 100', [req.user.resellerId]); res.json({ status: 'OK', notifications: r.rows }); }
    catch (e) { console.error('Notifications error:', e); res.status(500).json({ status: 'ERROR', message: 'Could not load notifications.' }); }
  });
  app.patch('/api/resellers/notifications/:id/read', authenticateToken, requireReseller, async (req, res) => {
    try { const r = await pool.query('UPDATE reseller_notifications SET read_at=NOW() WHERE id=$1 AND reseller_id=$2 RETURNING id,read_at', [req.params.id, req.user.resellerId]); if (!r.rowCount) return res.status(404).json({ status: 'ERROR', message: 'Notification not found.' }); res.json({ status: 'OK', notification: r.rows[0] }); }
    catch (e) { console.error('Mark notification read error:', e); res.status(500).json({ status: 'ERROR', message: 'Could not update notification.' }); }
  });
}
async function getSalesPaused(pool) { const r = await pool.query("SELECT setting_value FROM platform_settings WHERE setting_key='sales_paused'"); return Boolean(r.rows[0]?.setting_value?.paused); }
module.exports = { installOperations, isWithinDailyWindow, getSalesPaused, NAIROBI_TZ };
