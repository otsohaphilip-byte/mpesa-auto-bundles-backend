/* Admin pause/resume panel. Load after the existing admin dashboard markup. */
(function () {
  const dashboard = document.getElementById('dashboard'); if (!dashboard) return;
  const card = document.createElement('section'); card.className = 'card';
  card.innerHTML = `<h3>Platform sales control</h3><p id="salesState" role="status">Loading sales status…</p><label for="pauseReason">Reason (optional)</label><input id="pauseReason" maxlength="250" placeholder="e.g. Supplier maintenance"><button id="salesToggle" type="button" disabled>Loading…</button><p><small>Pausing blocks new sales only. M-Pesa payment callbacks remain enabled to record payments already made.</small></p>`;
  dashboard.insertBefore(card, dashboard.children[1] || null);
  const stateText = card.querySelector('#salesState'), button = card.querySelector('#salesToggle'); let paused = false;
  const apiBase = window.API || 'https://mpesa-auto-bundles-backend.onrender.com';
  async function call(path, options = {}) { const token = sessionStorage.getItem('adminToken') || ''; const response = await fetch(apiBase + path, { ...options, headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + token, ...(options.headers || {}) } }); const data = await response.json().catch(() => ({})); if (!response.ok) throw new Error(data.message || 'Request failed'); return data; }
  async function refresh() { try { const data = await call('/api/system/sales-status'); paused = Boolean(data.paused); stateText.textContent = paused ? 'PAUSED — new sales are blocked.' : 'ACTIVE — sales are enabled.'; button.textContent = paused ? 'Resume sales' : 'Pause sales'; button.className = paused ? '' : 'warning'; button.disabled = false; } catch (e) { stateText.textContent = 'Could not load status: ' + e.message; button.disabled = true; } }
  button.addEventListener('click', async () => { button.disabled = true; try { const reason = card.querySelector('#pauseReason').value.trim(); await call('/api/admin/system/sales-status', { method: 'PATCH', body: JSON.stringify({ paused: !paused, reason }) }); await refresh(); if (typeof showMessage === 'function') showMessage('mainMessage', paused ? 'Platform sales paused.' : 'Platform sales resumed.'); } catch (e) { stateText.textContent = 'Update failed: ' + e.message; button.disabled = false; } });
  refresh();
})();
