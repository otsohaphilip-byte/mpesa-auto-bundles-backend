'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { isWithinDailyWindow } = require('../operations');
test('unscheduled offers always available', () => assert.equal(isWithinDailyWindow(null, null, new Date('2026-01-01T00:00:00Z')), true));
test('malformed schedule rejected', () => assert.equal(isWithinDailyWindow('25:00', '06:00', new Date('2026-01-01T00:00:00Z')), false));
test('normal window includes start and excludes end', () => { assert.equal(isWithinDailyWindow('09:00', '17:00', new Date('2026-01-01T06:00:00Z')), true); assert.equal(isWithinDailyWindow('09:00', '17:00', new Date('2026-01-01T14:00:00Z')), false); });
test('overnight window covers both sides of midnight', () => { assert.equal(isWithinDailyWindow('22:00', '06:00', new Date('2026-01-01T20:00:00Z')), true); assert.equal(isWithinDailyWindow('22:00', '06:00', new Date('2026-01-01T02:00:00Z')), true); assert.equal(isWithinDailyWindow('22:00', '06:00', new Date('2026-01-01T08:00:00Z')), false); });
test('equal start and end rejected', () => assert.equal(isWithinDailyWindow('08:00', '08:00', new Date('2026-01-01T00:00:00Z')), false));
